#include <bits/stdc++.h>

using namespace std;

#define range(i, n) for(int i=0; i<n; ++i)
typedef long long ll;

#define MOD 10000007.0
#define MAX 10030

int main()
{

    int n;
    scanf("%d", &n);

    int a, b, c;
    while(n--) {

        scanf("%d^%d", &a, &b);
        scanf("%d!", &c);

        int exp1[MAX], fat1[MAX];

        memset(exp1, 1, sizeof exp1);
        memset(fat1, 1, sizeof fat1);

        for(int i = 1; i <= b; i++) exp1[i] = a;
        for(int i = 1; i <= c; i++) fat1[i] = i;

        double div[MAX];
        double ans = 1.0;

        for(int i = 1; i < MAX; i++)
            div[i] = 1.0*exp1[i]/fat1[i];

        for(int i =1; i < MAX; i++) {
            ans = (ans * div[i]);
        }

        if(ans > 1) printf("exp\n");
        else printf("fat\n");

    }

    return 0;
}


