#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    scanf("%d", &n);

    double val;
    char type[5];

    for(int i=1; i<=n; ++i) {
        scanf("%lf %s", &val, type);

        if(strcmp(type, "kg") == 0) printf("%d %.4f lb\n", i, val * 2.2046);
        if(strcmp(type, "lb") == 0) printf("%d %.4f kg\n", i, val * 0.4536);
        if(strcmp(type, "l") == 0) printf("%d %.4f g\n", i, val * 0.2642);
        if(strcmp(type, "g") == 0) printf("%d %.4f l\n", i, val * 3.7854);
    }
}
