#include <bits/stdc++.h>
using namespace std;

#define range(i, n) for(int i=0; i<n; ++i)
typedef long long ll;

struct Quad {
    int x1, y1, x2, y2;
};

int main()
{
    int n;
    scanf("%d", &n);

    vector<Quad> panels;
    vector<Quad> lines;

    range(i, n) {
        int x1, y1, x2, y2;
        scanf("%d %d %d %d", &x1, &y1, &x2, &y2);
        panels.push_back({x1, y1, x2, y2});
    }



    return 0;
}

