#include <bits/stdc++.h>
using namespace std;

#define range(i, n) for(int i=0; i<n; ++i)
typedef long long ll;

bool solve() {
    int n, k;
    scanf("%d %d", &n, &k);

    bool fact[1018+1];
    range(i, 1018+1) fact[i] = false;

    while(k--) {
        int x;
        scanf("%d", &x);

        for(int i=2; i<=x; ++i) if(x%i == 0) {
            fact[i] = true;
            while(x%i == 0) x /= i;
        }
    }

    for(int i=2; i<=n; ++i) if(n%i == 0) {
        while(n%i == 0) n /= i;
        if(fact[i] == false) return false;
    }

    return true;
}

int main()
{
    int t;
    scanf("%d", &t);
    while(t--) puts(solve()? "Y" : "N");
    return 0;
}
