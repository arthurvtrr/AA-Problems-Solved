#include <bits/stdc++.h>

using namespace std;

int main() {

    int t, k, n;
    scanf("%d", &t);

    for(int j = 1; j <= t; j++) {

        char s[82];
        scanf("\n%d %s", &n, &s);
        printf("%d ", j);
        for(int i = 0; i < strlen(s); i++)
            if((i+1) != n) printf("%c", s[i]);
        printf("\n");
    }
    return 0;
}
