#include <stdio.h>
#include <algorithm>

using namespace std;

int main() {
    int t, k, n;
    scanf("%d", &t);

    for (int tc = 0; tc < t; tc++) {
        scanf("%d %d", &k, &n);

        int s1 = (1 + n) * n / 2;
        int s2 = n*n;
        int s3 = (2 + n*2) * n / 2;

        printf("%d %d %d %d\n", k, s1, s2, s3);
    }
    return 0;
}
