#include <bits/stdc++.h>

using namespace std;

#define range(i, n) for(int i=0; i<n; ++i)

typedef long long ll;

#define MAX 1001
#define pb push_back
#define mp make_pair

int n, m;

vector< pair<int,int> > adj[MAX];
int path[MAX], used[MAX];
vector<int> final_path;


void dijkstra() {

    priority_queue<pair<int, int> > pq;

    pq.push(mp(0, 1));
    path[1] = -1;

    while(!pq.empty()) {

        int w = -pq.top().first;
        int node = pq.top().second;
        pq.pop();

        for(int i = 0; i < adj[node].size(); i++) {
            if(adj[node][i].second == n) {
                final_path.push()
            }
        }

    }
}


int main() {

    while(scanf("%d %d", &n, &m) != EOF) {

        int x, y, w;
        for(int i = 0; i < m; i++) {
            scanf("%d %d %d", &x, &y, &w);
            adj[x].pb(mp(w, y));
            adj[y].pb(mp(w, x));
        }

        dijkstra();

    }


    return 0;
}
