#include <bits/stdc++.h>
using namespace std;

#define range(i, n) for(int i=0; i<n; ++i)
typedef long long ll;

struct Time {
    float ac, a, b;
    Time(int ac=0, int a=0, int b=0):
        ac(ac), a(a), b(b) {}

    bool operator< (const Time &rhs) const {
        return ac != rhs.ac? ac > rhs.ac:
            a * 20 + b < rhs.a * 20 + rhs.b;
    }
};

int main()
{
    while(true) {
        int t, p;
        scanf("%d %d", &t, &p);
        if(t == 0 and p == 0) break;

        Time time[t];

        range(i, t) {
            int ac=0, a=0, b=0;

            range(j, p) {
                char tempo[15];
                int tentativas;

                scanf("%d/%s", &tentativas, tempo);
                if(tempo[0] == '-') continue;

                a += tentativas - 1;
                b += atoi(tempo);
                ac += 1;
            }

            time[i] = Time(ac, a, b);
        }

        sort(time, time+t);

        int _min = 1;
        int _max = INT_MAX;

        range(i, t-1) {
            if(time[i].ac != time[i+1].ac) continue;
            if(time[i].a == time[i+1].a) continue;

            double limit = (time[i+1].b - time[i].b) / (time[i].a - time[i+1].a);

            if(limit > 20) _max = min((int) ceil(limit-1), _max);
            if(limit < 20) _min = max((int) floor(limit+1), _min);
            if(limit == 20) _min = _max = 20;
        }

        printf("%d ", _min);
        if(_max == INT_MAX) puts("*");
        else printf("%d\n", _max);
    }

    return 0;
}
