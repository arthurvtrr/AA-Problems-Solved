#include <bits/stdc++.h>
using namespace std;

#define range(i, n) for(int i=0; i<n; ++i)
typedef long long ll;

int main()
{
    return 0;
}
